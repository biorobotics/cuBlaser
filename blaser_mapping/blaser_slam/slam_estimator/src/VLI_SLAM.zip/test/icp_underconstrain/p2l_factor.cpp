//
// Created by dcheng on 11/22/20.
//

#include "p2l_factor.h"

double Point2PlaneICPFactor::sqrt_info;
double (*Point2PlaneICPFactor::para_pose_)[7];


template<>
double getDouble<double>(double var)
{
  return var;
}