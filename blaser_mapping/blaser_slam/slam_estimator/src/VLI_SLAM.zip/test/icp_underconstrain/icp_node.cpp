//
// Created by dcheng on 11/22/20.
//

#include "icp.h"

int main(int argc, char** argv)
{
  ICP icp_solver;
}