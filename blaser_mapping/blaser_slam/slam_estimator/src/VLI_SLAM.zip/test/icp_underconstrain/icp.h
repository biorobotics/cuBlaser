//
// Created by dcheng on 11/22/20.
//

#ifndef VINS_ESTIMATOR_ICP_H
#define VINS_ESTIMATOR_ICP_H

#include <pcl_ros/point_cloud.h>
#include <pcl/kdtree/kdtree_flann.h>
#include "../../parameters.h"
#include "points_generator.h"
#include <pcl_ros/transforms.h>
#include <pcl/features/normal_3d.h>
#include "p2l_factor.h"
#include <pcl/io/ply_io.h>
#include "../../factor/underconstrain_pose_local_param.h"
#include "../../factor/pose_local_parameterization.h"

using Eigen::MatrixXd;

void printEigenOfCovarianceFromJacobian(const MatrixXd& grad);

class ICP
{
public:
  ICP();

private:
  void initPcd();

  void alignPointcloud();

  void initialICP();

  void underconstrainedICP();

  pcl::PointCloud<pcl::PointXYZINormal>::Ptr src_;
  pcl::PointCloud<pcl::PointXYZINormal>::Ptr dst_;

  pcl::KdTreeFLANN<pcl::PointXYZINormal>::Ptr kdtree_;

  double para_pose_[7];

  MatrixXd eigvals_, eigvecs_;

};



#endif //VINS_ESTIMATOR_ICP_H
